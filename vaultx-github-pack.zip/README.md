<div align="center">

# VAULTX

### Every curve token, behind one door.

**Live board and trading front-end for Pons bonding-curve tokens on Robinhood Chain.**

[**Launch App**](https://vaultx-apps.github.io/vaultx/) · [**Swap**](https://vaultx-apps.github.io/vaultx/#/swap) · [**Launchpads**](https://vaultx-apps.github.io/vaultx/#/launchpads) · [**Portfolio**](https://vaultx-apps.github.io/vaultx/#/portfolio) · [**$VAULTX**](https://vaultx-apps.github.io/vaultx/#/vaultx) · [**Docs**](https://vaultx-apps.github.io/vaultx/#/docs) · [**Report an Issue**](https://github.com/vaultx-apps/vaultx/issues)

</div>

---

## Overview

VaultX is a Web3 application focused on token discovery, bonding-curve activity, and token trades on **Robinhood Chain**.

The platform brings Pons launchpad token data, token lifecycle information, and market-oriented tools together in one responsive interface. VaultX is built to make emerging markets easier to explore while clearly distinguishing available on-chain evidence from estimates or unavailable data.

> **Project status:** The application is under active development. Some features require supported contracts, configured data providers, and a connected wallet. Displayed market data can be delayed or unavailable.

## Platform Features

| Feature | Description |
| --- | --- |
| **Live Token Discovery** | Browse every Pons launch with search, sorting, and lifecycle filters. |
| **Bonding-Curve Lifecycle** | Follow tokens through **On Curve**, **Graduating**, and **Surfaced** stages. |
| **Buy & Sell the Curve** | Trade directly against the bonding curve at its constant-product price, including the curve's real **3.8% input fee**. No VaultX markup. |
| **Graduation Tracking** | A token graduates at **4.2 ETH** real reserve, then keeps trading on its Uniswap pool (linked via DexScreener). |
| **Swap Interface** | A dedicated swap view with a searchable token picker, using the same live token list and the same quoting as the detail view. |
| **Launchpads** | Pons at a glance: live launch stats and the same token grid. |
| **Portfolio** | Connect a wallet and see the curve tokens it actually holds, valued at live curve prices (ETH + USD), with a total-value summary. |
| **$VAULTX Information** | View the project token overview. **$VAULTX is not launched: there is no contract address, no price, and nowhere to buy it yet.** |
| **Responsive UI** | Navigate a navy + brass-gold interface that works on desktop and mobile. |
| **RPC Resilience** | Three Robinhood RPC endpoints with automatic failover and a stale-data banner, so one failing endpoint never blanks the board. |

Market metrics and displayed statuses depend on network conditions, provider availability, and the scope of the underlying checks.

## Explore the App

| Section | URL | Purpose |
| --- | --- | --- |
| Token Discovery | [vaultx-apps.github.io/vaultx](https://vaultx-apps.github.io/vaultx/) | Live tokens, lifecycle filters, and the token board |
| Swap | [#/swap](https://vaultx-apps.github.io/vaultx/#/swap) | Token swap interface |
| Launchpads | [#/launchpads](https://vaultx-apps.github.io/vaultx/#/launchpads) | Supported launchpad information |
| Portfolio | [#/portfolio](https://vaultx-apps.github.io/vaultx/#/portfolio) | Wallet holdings valued at live curve prices |
| $VAULTX | [#/vaultx](https://vaultx-apps.github.io/vaultx/#/vaultx) | Project token overview (coming soon) |
| Documentation | [#/docs](https://vaultx-apps.github.io/vaultx/#/docs) | Curve mechanics, fee, graduation, and risks |

## Contracts on Robinhood Chain

VaultX reads live data from the **Pons** protocol contracts on Robinhood Chain. These are the protocol addresses the site uses — VaultX itself deploys no contracts:

```text
Pons V2 factory:  0x7ed598bcef8bd9edd8c97a195c6d13f40801ec7e
Fee Escrow:       0xd3AFEB2a57f70eF218Aa82451c51B2fb0416Ac9e
Fee policy/hook:  0xE5e702641Ea86F4ae6cC3cDaeD2B886f976Be044
```

- **Network:** Robinhood Chain (chain ID 4663)
- **Factory explorer:** [View on Blockscout](https://robinhoodchain.blockscout.com/address/0x7ed598bcef8bd9edd8c97a195c6d13f40801ec7e)
- **Fee Escrow explorer:** [View on Blockscout](https://robinhoodchain.blockscout.com/address/0xd3AFEB2a57f70eF218Aa82451c51B2fb0416Ac9e)

## $VAULTX Token

**$VAULTX is not launched.** There is no contract address, no price, no tokenomics, and nowhere to buy it yet.

> **Scam guard:** Anything claiming to be $VAULTX before the official announcement is fake. Confirm any future contract address on this repository and the official site before trading.

## How VaultX Fits the Token Lifecycle

```text
Supported Launchpad (Pons)
       |
       v
   On Curve
       |
       v
   Graduating
       |
       v
    Surfaced
       |
       +--> Token discovery & market views
       +--> Buy / sell against the curve
       +--> Portfolio valuation
       +--> Graduation tracking (DexScreener link)
```

Lifecycle labels reflect available application data; they should not be treated as proof that any specific transaction route is safe or available.

## Technology Stack

| Layer | Technology |
| --- | --- |
| Application | Single self-contained `index.html` — no build step, no backend |
| Language | JavaScript (vanilla, no framework) |
| Styling | Hand-written CSS (navy + brass-gold) |
| Blockchain interaction | Direct JSON-RPC + EIP-1193 wallet |
| Token images | Token `logo()` with four IPFS gateway fallbacks |
| CI | GitHub Actions (Pages deploy) |
| Target network | Robinhood Chain (4663) |

## Project Structure

```text
index.html                 # The whole site — board, Swap, Launchpads, Portfolio, Docs
.github/workflows/
  pages.yml                # GitHub Pages deploy workflow
LICENSE                    # MIT
README.md
```

## Local Development

### Requirements

- Git.
- A modern browser, or Python 3 for the local server option.
- No build step, no package manager, no environment variables.

### Installation

```bash
git clone https://github.com/vaultx-apps/vaultx.git
cd vaultx
```

### Run it

```bash
# Option 1: open the file directly
open index.html

# Option 2: serve it locally
python3 -m http.server 8000
# then open http://localhost:8000
```

> The site reads live data from Robinhood Chain RPC endpoints. A fresh clone needs network access to those endpoints before live prices and wallet-dependent features operate.

## Deploy

**GitHub Pages** (free, live):

1. Push to the `main` branch — the deploy workflow publishes automatically.
2. Your site is live at `https://vaultx-apps.github.io/vaultx/`.

**Vercel:** import the repo, or drag `index.html` into a project as a single file (it must be named `index.html` at the project root). Mirror: https://vaultx-2.vercel.app

## Development Roadmap

### Implemented in the application

- [x] Live token board with search, sorting, and lifecycle filters.
- [x] Token detail with price chart from real curve trades.
- [x] Buy/Sell panel quoting constant-product price including the 3.8% fee.
- [x] Swap view with searchable token picker.
- [x] Launchpads view with live Pons stats and the Pons logo.
- [x] Portfolio view with live curve valuations.
- [x] $VAULTX coming-soon page with scam guard.
- [x] Docs view (curve mechanics, fee, graduation, risks).
- [x] RPC failover across three endpoints with stale-data banner.
- [x] Token logos from `logo()` with four IPFS gateway fallbacks.

### Ongoing priorities

- [ ] Verify swap picker and trade flows live on the deployed site.
- [ ] Test buy/sell with small real funds.
- [ ] Secure the @VaultX handle on X.
- [ ] Decide the $VAULTX launch plan (tokenomics, distribution).
- [ ] Keep contract details consistent across the site, repo, and announcements.

See [GitHub Issues](https://github.com/vaultx-apps/vaultx/issues) for tracked work and proposals. Implemented UI should not be taken as evidence that every live integration has been fully verified.

## Development Workflow

| Branch | Purpose |
| --- | --- |
| `main` | Release-oriented source |
| `feature/*` | Isolated feature changes |
| `fix/*` | Bug fixes |

Features are developed in focused commits and reviewed through pull requests.

## Security & Disclaimer

- Never commit private keys, seed phrases, passwords, or provider secrets.
- Independently verify token contract addresses and transaction parameters.
- Review wallet prompts before confirming a transaction. Trades are real on-chain transactions — always test with a small amount first.
- Treat market estimates as informational, not as a guarantee of safety.

**VaultX has not been represented here as independently audited.** Interacting with digital assets involves financial, smart-contract, and network risks. Bonding-curve tokens are extremely volatile and many go to zero. Nothing in this repository or application constitutes investment advice. VaultX charges no fee and never holds your funds.

## Contributing

Bug reports, documentation corrections, and feature proposals are welcome. Read [CONTRIBUTING.md](CONTRIBUTING.md) and use [GitHub Issues](https://github.com/vaultx-apps/vaultx/issues) to discuss changes.

## Links

- **Website:** https://vaultx-apps.github.io/vaultx/
- **Vercel mirror:** https://vaultx-2.vercel.app
- **X:** https://x.com/VaultX
- **Repository:** https://github.com/vaultx-apps/vaultx

---

<div align="center">

**VAULTX**
*Every curve token, behind one door.*
Robinhood Chain Ecosystem

</div>
